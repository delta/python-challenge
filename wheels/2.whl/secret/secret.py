# Great, you've completed this PoC!

def secret21vsv3245fdf345tgscvxerw3():
    # Hi there, now find a top level comment in the file in which this function was declared!
    print('Great, now find the source of this function. The next clue is in a comment in this function ')
