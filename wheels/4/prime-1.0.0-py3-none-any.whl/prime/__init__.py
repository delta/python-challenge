from .prime import *
