import numpy as np

my_matrix = np.arange(10000).reshape((100, 100))
